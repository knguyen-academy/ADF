# PACT.Utilities

This solution is intended to house the various utility libraries PACT has developed for internal use. ActiveDirectoryFunctions is the first to move in, likely followed by versions of ITSelfServiceUtil, ServiceDeskUtil, and/or any other libraries that run into issues during our effort to remove credentials from source code and configs.

Each library will be in its own project and will have a pipeline definition that automatically versions, packages, and publishes pre-release and full versions to our PACT artifact feed in Azure DevOps. The .azure-pipelines directory in the root of this repository has the pipeline templates that help make this possible.
