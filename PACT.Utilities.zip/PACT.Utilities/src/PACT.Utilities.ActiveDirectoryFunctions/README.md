﻿# PACT.Utilities.ActiveDirectoryFunctions

Functions to manage Active Directory groups and attributes.

## 0.2.0

- Add net9.0-windows and net10.0-windows target frameworks
- Upgrade NuGet packages
- Breaking change: remove obsolete methods, commented out methods, and methods with no usage according to ADOS code search
- resolve all warnings that could be resolved without public API changes
  - including nullable analysis, doing best to preserve current behavior even if that meant not fixing something.
- incorporate changes made to old codebase ($/FTB/PACT/AD_Functions/Active_Directory_Functions)
  - add Update_AD_Attr_User method
  - update exchange server from FG3012 to FG3018

## 0.1.2

This version upgrades NuGet packages and changes the targeted .NET Framework version from 4.6.1, which is out of support, to 4.6.2.

## 0.1.1

This version upgrades NuGet packages and drops the .NET 6 target as it is out of support.

## 0.1.0

This version is nearly identical to the old version of this library (Active_Directory_Functions). No method signatures have changed, but some methods have been annotated with the Obsolete attribute to dissuade their use.

The default constructor makes a connection to PACTPRDSQL using integrated security to retrieve the credentials that used to be hard-coded. It is highly recommended to get these credentials in the calling application and pass them to the new constructor that accepts a user name and password.

A complete rewrite should be considered/expected for version 1.0.0.
