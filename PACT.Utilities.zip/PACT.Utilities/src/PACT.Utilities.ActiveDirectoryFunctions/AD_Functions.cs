﻿#pragma warning disable CA1707 // Can't change public API of this class, so disable warning for underscores in names.
#pragma warning disable CA1822 // Can't change the public API of this class, so disable warning for making methods static.
#pragma warning disable CA1416 // Semi-temporary: Ignore "call site is reachable on all platforms". using e.g. "net10.0-windows" resulted in consumers having to target "net10.0-windows7.0".

using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.Protocols;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Net;
using System.Security;
using System.Security.AccessControl;
using System.Security.Cryptography.X509Certificates;
using FTBMainframeSecurity;

namespace PACT.Utilities.ActiveDirectoryFunctions;

public class AD_Functions
{
    private readonly string _domain = "ftb.ca.gov"; //Prod
    private readonly string _user; //Prod
    private readonly string _password; //Prod

    //private readonly string domain = "ftbstg.ftb.ca.gov"; //Dev
    //private readonly string user = "Stg_amu_sa"; //Dev
    //private readonly string password = "P@ssw0rd1"; //Dev

    private const string ExchangeServer = "FG3018";

    /// <summary>
    /// The credentials passed to this constructor will be used to make edits to Active Directory.
    /// </summary>
    /// <param name="userName">The unencrypted user name of a service account that can edit AD items/attributes.</param>
    /// <param name="password">The unencrypted password of a service account that can edit AD items/attributes.</param>
    public AD_Functions(string userName, string password)
    {
        _user = userName;
        _password = password;
    }

    #region Active Directory processes
    public int Disable_User_Account(string userId)
    {
        var successCode = 0;

        try
        {
            var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.Enabled = false;
            userPrincipal.Save();

            userPrincipal.Description =
                $"Account disabled by Administrative Account Inactivation Tool - {DateTime.Today.ToShortDateString().Replace('/', '-')}";
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Enable_User_Account(string userId)
    {
        var successCode = 0;

        try
        {
            var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.Enabled = true;
            userPrincipal.Save();

            userPrincipal.Description =
                $"Account Enabled by Access Management (Automation) - {DateTime.Today.ToShortDateString().Replace('/', '-')}";
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Move_User_Account(string distinguishedName, string eventCode)
    {
        var successCode = 0;

        if (string.IsNullOrWhiteSpace(distinguishedName))
        {
            successCode = 1;

            return successCode;
        }

        //If account is enabled and is in the Furlough OU, move account to the Sacramento OU.  If the account is a new separation,
        // then move the account to the appropriate OU.  Pass the strEventCode parameter to this routine for determination of the
        // correct OU.  1001 = Furlough OU, 1002 = Retirement OU, 1003 = LOA OU, 1004 Vendor Retire OU.
        try
        {
            //Dev
            // var newLocation = eventCode switch
            // {
            //     //Furlough
            //     "1001" => "OU=Furlough,OU=Separations,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            //     //Retirement
            //     "1002" => "OU=Retirement,OU=Separations,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            //     // LOA
            //     "1003" =>
            //         "OU=Leave of Absence,OU=Separations,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            //     // Inactive
            //     "1004" => "OU=Inactive,OU=Separations,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            //     // Vendor
            //     "1006" => "OU=Sacramento,OU=Users,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            //     // Active User or Vendor Retire
            //     _ => "OU=Sacramento,OU=Users,OU=ITSC,DC=ftbstg,DC=ftb,DC=ca,DC=gov",
            // };

            //Prod
            var newLocation = eventCode switch
            {
                //Furlough
                "1001" => "OU=Furlough,OU=Separations,OU=ITSC,DC=ftb,DC=ca,DC=gov",
                //Retirement
                "1002" => "OU=Retirement,OU=Separations,OU=ITSC,DC=ftb,DC=ca,DC=gov",
                // LOA
                "1003" => "OU=Leave of Absence,OU=Separations,OU=ITSC,DC=ftb,DC=ca,DC=gov",
                // Inactive
                "1004" => "OU=Inactive,OU=Separations,OU=ITSC,DC=ftb,DC=ca,DC=gov",
                // Vendor
                "1006" => "OU=Sacramento,OU=Users,OU=ITSC,DC=ftb,DC=ca,DC=gov",
                // Active User or Vendor Retire
                _ => "OU=Sacramento,OU=Users,OU=ITSC,DC=ftb,DC=ca,DC=gov",
            };
            var newOU = CreateLdapDirectoryEntry(newLocation);
            var currentLocation = CreateLdapDirectoryEntry(
                distinguishedName.Replace("LDAP://", "")
            );

            currentLocation.MoveTo(newOU);
        }
        catch (Exception)
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Add_User_To_ADGroup(string userId, string groupName)
    {
        var successCode = 0;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var group = GroupPrincipal.FindByIdentity(pc, groupName);

            group.Members.Add(pc, IdentityType.SamAccountName, userId);
            group.Save();
        }
        catch (Exception)
        {
            successCode = 1;
        }
        return successCode;
    }

    public string Add_User_To_Group(string userId, string groupName)
    {
        var status = string.Empty;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var groupPrincipal = GroupPrincipal.FindByIdentity(pc, groupName);

            groupPrincipal.Members.Add(pc, IdentityType.SamAccountName, userId);
            groupPrincipal.Save();
        }
        catch (Exception ex)
        {
            status = ex.Message;
        }

        return status;
    }

    public int Remove_User_From_ADGroup(string userId, string groupName)
    {
        var successCode = 0;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var group = GroupPrincipal.FindByIdentity(pc, groupName);

            group.Members.Remove(UserPrincipal.FindByIdentity(pc, userId));
            group.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public string Remove_User_From_Group(string userId, string groupName)
    {
        var status = string.Empty;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var groupPrincipal = GroupPrincipal.FindByIdentity(pc, groupName);

            groupPrincipal.Members.Remove(UserPrincipal.FindByIdentity(pc, userId));
            groupPrincipal.Save();
        }
        catch (Exception ex)
        {
            status = ex.Message;
        }

        return status;
    }

    public int Add_Group_To_ADGroup(string childGroupName, string parentGroupName)
    {
        var successCode = 0;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var parentGroup = GroupPrincipal.FindByIdentity(pc, parentGroupName);

            parentGroup.Members.Add(pc, IdentityType.SamAccountName, childGroupName);
            parentGroup.Save();
        }
        catch (Exception)
        {
            successCode = 1;
        }
        return successCode;
    }

    public int Add_Group_To_ADGroup_ByName(string childGroupName, string parentGroupName)
    {
        var successCode = 0;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var group = GroupPrincipal.FindByIdentity(pc, parentGroupName);

            group.Members.Add(GroupPrincipal.FindByIdentity(pc, childGroupName));
            group.Save();
        }
        catch (Exception)
        {
            successCode = 1;
        }
        return successCode;
    }

    public int Remove_Group_From_ADGroup(string childGroupName, string parentGroupName)
    {
        var successCode = 0;

        try
        {
            using var pc = new PrincipalContext(ContextType.Domain, _domain, _user, _password);
            using var group = GroupPrincipal.FindByIdentity(pc, parentGroupName);

            group.Members.Remove(GroupPrincipal.FindByIdentity(pc, childGroupName));
            group.Save();
        }
        catch (Exception)
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Remove_Security(string _, string userId)
    {
        var successCode = 0;

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal != null)
            {
                using var groups = userPrincipal.GetGroups(principalContext);

                foreach (var group in groups)
                {
                    if (group.Name != "Domain Users")
                    {
                        //group.Delete(); <---This removes the Security Group from AD!!! NEVER use!
                        var groupPrincipal = GroupPrincipal.FindByIdentity(
                            principalContext,
                            group.Name
                        );

                        groupPrincipal.Members.Remove(userPrincipal);
                        groupPrincipal.Save();
                    }
                }
            }
        }
        catch (Exception)
        {
            successCode = 1;
        }

        return successCode;
    }

    // This method is called from TechAdminTools.WebApp
    public int Change_Primary_SMTP(string userId, string proxy)
    {
        var successCode = 0;

        // set proxy address to proper format.
        proxy = proxy.Replace("FTB", "ftb.ca.gov");

        //Check to see if the user is a vendor.  If so, place "Vendor." in front of the variable proxy.
        if (get_PUC(userId)?.Equals("ven", StringComparison.OrdinalIgnoreCase) == true)
        {
            proxy = $"Vendor.{proxy}".Replace("(Vendor)", "");
        }

        proxy = proxy.Replace(",", ".").Trim();
        proxy = proxy.Replace(" ", "");

        //Search AD for user
        //Get proper location and credentials to do the AD work.
        var entry = CreateLdapDirectoryEntry();
        var mySearcher = new DirectorySearcher(entry)
        {
            Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
        };
        mySearcher.PropertiesToLoad.Add("proxyAddresses");

        try
        {
            var result = mySearcher.FindOne();

            if (result is null)
            {
                successCode = 1;

                return successCode;
            }

            var de = result.GetDirectoryEntry();
            var newProxy = new List<string>();

            //Loop thru and change any existing SMTP to lower case smtp...
            foreach (string item in de.Properties["proxyAddresses"])
            {
                if ($"smtp:{proxy}" == item)
                {
                    newProxy.Remove(item);
                }
                else
                {
                    newProxy.Add(item.Replace("SMTP", "smtp"));
                }
            }

            //Apply new primary SMTP to proxy address list
            newProxy.Add($"SMTP:{proxy}");

            de.Properties["proxyAddresses"].Value = null;
            de.CommitChanges();

            //Apply new proxy address list to user account.
            var x = 0;
            foreach (var proxyAddress in newProxy)
            {
                de.Properties["proxyAddresses"].Insert(x, proxyAddress);
                x += 1;
            }
            de.CommitChanges();

            successCode = Enable_Exchange_MB(userId);
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Clear_Home(string userId)
    {
        var successCode = 0;

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.HomeDirectory = null;
            userPrincipal.HomeDrive = null;
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    // TODO: make this operate with an authorized PrincipalContext instead.
    /// <summary>
    /// This code will only work if the caller is running as an account that can write to AD.
    /// </summary>
    /// <param name="userId">A valid FTB user id</param>
    /// <returns></returns>
    public int Clear_Photo(string userId)
    {
        var successCode = 0;
        var userDistinguishedName = Get_DN(userId);

        try
        {
            // Connect to AD
            using var user = new DirectoryEntry(userDistinguishedName);

            // Clear existing picture if exists
            user.Properties["jpegPhoto"].Clear();
            user.Properties["thumbNailPhoto"].Clear();
            user.CommitChanges();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Set_Home(string userId)
    {
        var successCode = 0;
        var userIdLetter = userId.Substring(0, 1);

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.HomeDirectory =
                $@"\\ftb\users\{userIdLetter.ToUpperInvariant()}\{userId.ToUpperInvariant()}";
            userPrincipal.HomeDrive = "P:";
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Update_Surname(string userId, string newSurname)
    {
        var successCode = 0;

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.Surname = newSurname;
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Update_GivenName(string userId, string newGivenName)
    {
        var successCode = 0;

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.GivenName = newGivenName;
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int delete_contact(string userId)
    {
        var successCode = 0;

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=contact)(objectclass=contact)(initials={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            var result = mySearcher.FindOne();

            if (result is null)
            {
                successCode = 1;

                return successCode;
            }

            using var de = result.GetDirectoryEntry();
            using var contact = de.Parent;

            contact.Children.Remove(de);
            contact.CommitChanges();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Update_DisplayName(string userId, string newDisplayName)
    {
        var successCode = 0;

        if (string.IsNullOrEmpty(newDisplayName) || newDisplayName.IsWhiteSpace())
        {
            successCode = 1;

            return successCode;
        }

        // If user is a vendor, adjust the display name.
        if (get_PUC(userId)?.Equals("ven", StringComparison.OrdinalIgnoreCase) == true)
        {
            newDisplayName =
                $"{newDisplayName.Substring(0, newDisplayName.IndexOf('@'))}(Vendor)@FTB";
        }

        try
        {
            using var principalContext = new PrincipalContext(
                ContextType.Domain,
                _domain,
                _user,
                _password
            );
            using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

            if (userPrincipal == null)
            {
                successCode = 1;

                return successCode;
            }

            userPrincipal.DisplayName = newDisplayName;
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Clear_Manager(string userId)
    {
        var successCode = 0;
        using var entry = CreateLdapDirectoryEntry();
        using var mySearcher = new DirectorySearcher(entry)
        {
            Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
        };
        mySearcher.PropertiesToLoad.Add("manager");

        var result = mySearcher.FindOne();

        if (result == null)
        {
            successCode = 1;

            return successCode;
        }

        using var de = result.GetDirectoryEntry();
        var manager = result.Properties["manager"];

        if (manager.Count > 0)
        {
            try
            {
                de.Properties["manager"].Value = null;
                de.CommitChanges();
            }
            catch
            {
                successCode = 1;
            }
        }
        else
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Clear_Phone(string userId)
    {
        var successCode = 0;
        using var entry = CreateLdapDirectoryEntry();
        using var mySearcher = new DirectorySearcher(entry)
        {
            Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
        };
        mySearcher.PropertiesToLoad.Add("telephoneNumber");
        mySearcher.PropertiesToLoad.Add("facsimileTelephoneNumber");
        var result = mySearcher.FindOne();

        if (result == null)
        {
            successCode = 1;

            return successCode;
        }

        using var de = result.GetDirectoryEntry();

        try
        {
            de.Properties["telephoneNumber"].Value = null;
            de.Properties["facsimileTelephoneNumber"].Value = null;
            de.CommitChanges();
        }
        catch (Exception)
        {
            successCode = 1;
        }

        return successCode;
    }

    public string Get_DN(string userId)
    {
        userId = userId.ToLowerInvariant();
        using var entry = CreateLdapDirectoryEntry();
        using var mySearcher = new DirectorySearcher(entry)
        {
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
            Filter =
                userId.Length == 5 || userId.Length == 6 && userId != "ftbvpn"
                    ? $"(&(objectCategory=user)(sAMAccountName={userId}))"
                    : $"(&(objectCategory=group)(sAMAccountName={userId}))",
        };
        mySearcher.PropertiesToLoad.Add("distinguishedName");

        var result = mySearcher.FindOne();

        return result is null ? string.Empty : result.Path;
    }

    public string? Get_Alias(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName == null)
        {
            return null;
        }

        userPrincipal.DisplayName = userPrincipal.DisplayName.Replace("@FTB", "");

        var separatorPosition = userPrincipal.DisplayName.IndexOf(',');
        var lastName = userPrincipal.DisplayName.Substring(0, separatorPosition);
        var firstName = userPrincipal.DisplayName.Substring(
            separatorPosition + 1,
            userPrincipal.DisplayName.Length - (separatorPosition + 1)
        );

        var strAlias = $"FTB{firstName}{lastName}";
        //strAlias = strAlias.Replace("(Vendor)", "");
        strAlias = strAlias.Replace("(", "{");
        strAlias = strAlias.Replace(")", "}");
        strAlias = strAlias.Replace(" ", "");

        return strAlias;
    }

    public string Get_AD_Attr(string userId, string attributeName)
    {
        var attributeValue = string.Empty;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            return attributeValue;
        }

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            mySearcher.PropertiesToLoad.Add("sAMAccountName");
            mySearcher.PropertiesToLoad.Add(attributeName);
            var result = mySearcher.FindOne();

            if (result is null)
            {
                return attributeValue;
            }

            using var de = result.GetDirectoryEntry();

            attributeValue = de.Properties[attributeName].Value?.ToString() ?? string.Empty;
        }
        catch (Exception) { }

        return attributeValue;
    }

    public string Get_AD_Attr_Groups(string userId, string attributeName)
    {
        var attributeValue = string.Empty;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            return attributeValue;
        }

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=group)(sAMAccountName={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            mySearcher.PropertiesToLoad.Add("sAMAccountName");
            mySearcher.PropertiesToLoad.Add(attributeName);
            var result = mySearcher.FindOne();

            if (result is null)
            {
                return attributeValue;
            }

            using var de = result.GetDirectoryEntry();

            attributeValue = de.Properties[attributeName].Value?.ToString() ?? string.Empty;
        }
        catch (Exception) { }

        return attributeValue;
    }

    public string Get_AD_Attr_User(string userId, string attributeName)
    {
        var attributeValue = string.Empty;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            return attributeValue;
        }

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            mySearcher.PropertiesToLoad.Add("sAMAccountName");
            mySearcher.PropertiesToLoad.Add(attributeName);
            var result = mySearcher.FindOne();

            if (result is null)
            {
                return attributeValue;
            }

            using var de = result.GetDirectoryEntry();

            attributeValue = de.Properties[attributeName].Value?.ToString() ?? string.Empty;
        }
        catch (Exception) { }

        return attributeValue;
    }

    public int Update_AD_Attr(string userId, string attributeName, string attributeValue)
    {
        var successCode = 0;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            successCode = 1;

            return successCode;
        }

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            mySearcher.PropertiesToLoad.Add("sAMAccountName");
            mySearcher.PropertiesToLoad.Add(attributeName);
            var result = mySearcher.FindOne();

            if (result is null)
            {
                successCode = 1;

                return successCode;
            }

            using var de = result.GetDirectoryEntry();

            de.Properties[attributeName].Value = attributeValue;
            de.CommitChanges();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public string Update_AD_Attr_User(string userId, string attributeName, string attributeValue)
    {
        var result = string.Empty;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            result = "Attribute name was null, empty, or white space.";

            return result;
        }

        try
        {
            using var directoryEntry = CreateLdapDirectoryEntry();
            using var searcher = new DirectorySearcher(directoryEntry)
            {
                Filter = $"(&(objectCategory=user)(sAMAccountName={userId}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
                PropertiesToLoad = { "sAMAccountName", attributeName },
            };
            using var searchResult = searcher.FindOne()?.GetDirectoryEntry();

            if (searchResult != null)
            {
                searchResult.Properties[attributeName].Value = attributeValue;
                searchResult.CommitChanges();
            }
            else
            {
                result = "Account not found";
            }
        }
        catch (Exception ex)
        {
            result = ex.Message;
        }

        return result;
    }

    public int Update_Group_AD_Attr(string groupName, string attributeName, string attributeValue)
    {
        var successCode = 0;

        if (string.IsNullOrWhiteSpace(attributeName))
        {
            successCode = 1;

            return successCode;
        }

        try
        {
            using var entry = CreateLdapDirectoryEntry();
            using var mySearcher = new DirectorySearcher(entry)
            {
                Filter = $"(&(objectCategory=group)(sAMAccountName={groupName}))",
                SearchScope = System.DirectoryServices.SearchScope.Subtree,
                PageSize = 10000,
            };
            mySearcher.PropertiesToLoad.Add("sAMAccountName");
            var result = mySearcher.FindOne();

            if (result is null)
            {
                successCode = 1;

                return successCode;
            }

            using var de = result.GetDirectoryEntry();

            if (de.Properties[attributeName].Value == null)
            {
                de.Properties[attributeName].Value = $"{DateTime.Now:d} -- {attributeValue}";
                de.CommitChanges();
            }
            else
            {
                de.Properties[attributeName].Value =
                    $"{de.Properties[attributeName].Value?.ToString()}{Environment.NewLine}{DateTime.Now:d} -- {attributeValue}";
                de.CommitChanges();
            }
        }
        catch (Exception)
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Update_Description(string userId, string newDescription)
    {
        var successCode = 0;

        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal is null)
        {
            successCode = 1;

            return successCode;
        }

        try
        {
            userPrincipal.Description =
                $"{newDescription}{DateTime.Today.ToShortDateString().Replace("/", "-")}{Environment.NewLine}";
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public string? Get_DisplayName(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        return userPrincipal?.DisplayName ?? null;
    }

    public string? Get_Name(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        return userPrincipal?.Name;
    }

    public int Verify_DisplayName(string displayName)
    {
        using var entry = CreateLdapDirectoryEntry();
        using var mySearcher = new DirectorySearcher(entry)
        {
            Filter = $"(&(objectCategory=user)(displayName={displayName}))",
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
        };

        var result = mySearcher.FindOne();

        return result == null ? 0 : 1;
    }

    public string? Get_Mail(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties["mail"][0]?.ToString();
    }

    public string? Get_Fname(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties["givenName"][0]?.ToString();
    }

    public string? Get_Lname(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties["sn"][0]?.ToString();
    }

    public string? Get_mailstore(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if ((userPrincipal?.DisplayName) == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties["homeMDB"][0]?.ToString();
    }

    public string get_OU(string userID)
    {
        using var entry = CreateLdapDirectoryEntry();
        using var mySearcher = new DirectorySearcher(entry)
        {
            Filter = $"(&(objectCategory=user)(sAMAccountName={userID}))",
            SearchScope = System.DirectoryServices.SearchScope.Subtree,
            PageSize = 10000,
        };
        mySearcher.PropertiesToLoad.Add("distinguishedName");

        var result = mySearcher.FindOne();
        var ou =
            result?.GetDirectoryEntry().Properties["distinguishedName"].Value?.ToString()
            ?? string.Empty;

        if (ou.Contains("Separations", StringComparison.OrdinalIgnoreCase))
        {
            ou = "Separations";
        }

        return ou;
    }

    public string? Get_User_Property(string userId, string property)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if ((userPrincipal?.SamAccountName) == null)
        {
            return "Nothing";
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties[property]?[0]?.ToString();
    }

    public string? get_PUC(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if ((userPrincipal?.DisplayName) == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return userPrincipal.DisplayName.Contains("vendor", StringComparison.OrdinalIgnoreCase)
            ? "VEN"
            : (de.Properties["departmentNumber"]?[0]?.ToString());
    }

    public string? get_Manager(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if ((userPrincipal?.DisplayName) == null)
        {
            return null;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        return de.Properties["Manager"]?[0]?.ToString();
    }

    public string getUserStatus(string userId)
    {
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        return userPrincipal?.Enabled is true ? "Enabled" : "Disabled";
    }

    public int Initialize_Fax(string userId)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName is null)
        {
            return 1;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        try
        {
            var fax1 = de.Properties["fen-UM-AllowCoversheetOverride"]?[0]?.ToString();
            var fax2 = de.Properties["fen-UM-AllowedToSendFax"]?[0]?.ToString();

            if (fax1 is not null && fax1.Equals("False", StringComparison.OrdinalIgnoreCase))
            {
                de.Properties["fen-UM-AllowCoversheetOverride"].Value = true;
            }

            if (fax2 is not null && fax2.Equals("False", StringComparison.OrdinalIgnoreCase))
            {
                de.Properties["fen-UM-AllowedToSendFax"].Value = true;
            }

            if (de.Properties["fen-UM-Coversheet"]?.Value == null)
            {
                de.Properties["fen-UM-Coversheet"].Value = "DEFAULT.CS";
            }

            de.CommitChanges();
        }
        catch
        {
            de.Properties["fen-UM-AllowCoversheetOverride"].Value = true;
            de.Properties["fen-UM-AllowedToSendFax"].Value = true;
            de.Properties["fen-UM-Coversheet"].Value = "DEFAULT.CS";
            de.CommitChanges();
        }

        return successCode;
    }

    public int Assign_Fax(string userId, string dir, string fax)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal?.DisplayName == null)
        {
            return 1;
        }

        // Set Attributes, create proxy address entry, apply attributes facsimileTelephoneNumber
        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();
        try
        {
            var sAddress = $"DIR:{dir}_{userId}".ToUpperInvariant();
            var bolOver = de.Properties["fen-UM-AllowCoversheetOverride"].ToString();
            var bolAllow = de.Properties["fen-UM-AllowedToSendFax"].ToString();
            var strFax1 = de.Properties["facsimileTelephoneNumber"].ToString();
            var strFaxOther = de.Properties["otherfacsimileTelephoneNumber"].ToString();
            var strCover = de.Properties["fen-UM-Coversheet"].ToString();
            var blsFound = false;
            var count = de.Properties["proxyAddresses"].Count;

            if (bolOver is null || bolAllow is null)
            {
                return 1;
            }

            foreach (string item in de.Properties["proxyAddresses"])
            {
                if (item.ToString().Equals(sAddress, StringComparison.OrdinalIgnoreCase))
                {
                    blsFound = true;

                    break;
                }
            }

            if (!blsFound)
            {
                de.Properties["proxyAddresses"].Insert(0, sAddress);
                de.Properties["fen-UM-Coversheet"].Value = "DEFAULT.CS";

                if (de.Properties["facsimileTelephoneNumber"].Value != null)
                {
                    de.Properties["otherfacsimileTelephoneNumber"].Value = fax;
                }
                else
                {
                    de.Properties["facsimileTelephoneNumber"].Value = fax;
                }

                if (!bolAllow.ToString().Equals("true", StringComparison.OrdinalIgnoreCase))
                {
                    de.Properties["fen-UM-AllowedToSendFax"].Value = true;
                }

                if (!bolOver.ToString().Equals("true", StringComparison.OrdinalIgnoreCase))
                {
                    de.Properties["fen-UM-AllowCoversheetOverride"].Value = true;
                }
            }

            de.CommitChanges();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Remove_Fax(string userId, string dir, string fax)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        // Set Attributes, create proxy address entry, apply attributes facsimileTelephoneNumber
        if (userPrincipal?.DisplayName == null)
        {
            return 1;
        }

        var de = (DirectoryEntry)userPrincipal.GetUnderlyingObject();

        try
        {
            var sAddress = $"DIR:{dir}_{userId}".ToUpperInvariant();

            //Remove FAX properties
            de.Properties["fen-UM-Coversheet"].Value = null;
            de.Properties["fen-UM-AllowedToSendFax"].Value = false;
            de.Properties["fen-UM-AllowCoversheetOverride"].Value = false;
            try
            {
                if (de.Properties["facsimileTelephoneNumber"].Value?.ToString() != fax)
                {
                    de.Properties["otherfacsimileTelephoneNumber"].Value = null;
                }
                else
                {
                    de.Properties["facsimileTelephoneNumber"].Value = null;
                }
            }
            catch (Exception) { }

            //only remove FAX entry from ProxyAddresses
            foreach (string item in de.Properties["proxyAddresses"])
            {
                if (item.ToString().Equals(sAddress, StringComparison.OrdinalIgnoreCase))
                {
                    de.Properties["proxyAddresses"].Remove(sAddress);
                    break;
                }
            }

            de.CommitChanges();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public int Set_Password(string struserID, string PW = "Newpassword@123")
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, struserID);

        try
        {
            userPrincipal.SetPassword(PW);
            userPrincipal.ExpirePasswordNow();
            userPrincipal.Save();
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }

    public string generateRandomPassword(
        int passwordLength = 8,
        int alphaChars = 2,
        int numericChars = 2
    )
    {
        var allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
        var allowedNumbers = "0123456789";
        var allowedNonAlphaNum = "@#$";
        var rd = new Random();

        if (
            (alphaChars + numericChars) > passwordLength
            || passwordLength <= 0
            || alphaChars < 0
            || numericChars < 0
        )
            throw new ArgumentOutOfRangeException(
                $"{nameof(passwordLength)} must be greater than 0. {nameof(alphaChars)} and {nameof(numericChars)} must be greater than or equal to 0. {passwordLength} must be greater than or equal to {nameof(alphaChars)} + {nameof(numericChars)}."
            );

        var passwordBuffer = new char[passwordLength];
        var pos = new int[passwordLength];
        var i = 0;

        //Random the position values of the pos array for the string Pass
        while (i < passwordLength - 1)
        {
            var flag = false;
            var temp = rd.Next(0, passwordLength);

            for (var j = 0; j < passwordLength; j++)
            {
                if (temp == pos[j])
                {
                    flag = true;
                    j = passwordLength;
                }
            }

            if (!flag)
            {
                pos[i] = temp;
                i++;
            }
        }

        //Random the AlphaNumericChars
        for (i = 0; i < passwordLength - (alphaChars + numericChars); i++)
        {
            passwordBuffer[i] = allowedChars[rd.Next(0, allowedChars.Length)];
        }

        //Random the alphaChars
        for (i = passwordLength - (alphaChars + numericChars); i < passwordLength - alphaChars; i++)
        {
            passwordBuffer[i] = allowedNumbers[rd.Next(0, allowedNonAlphaNum.Length)];
        }

        //Random the numericChars
        for (i = passwordLength - alphaChars; i < passwordLength; i++)
        {
            passwordBuffer[i] = allowedNonAlphaNum[rd.Next(0, allowedNonAlphaNum.Length)];
        }

        //Set the sorted array values by the pos array for the right position
        var sorted = new char[passwordLength];
        for (i = 0; i < passwordLength; i++)
        {
            sorted[i] = passwordBuffer[pos[i]];
        }

        return $"i{new string(sorted)}";
    }
    #endregion Active Directory processes

    #region Exchange processes
    public int Disable_Exchange_MB(string userId)
    {
        var successCode = 0;
        var liveIdConnectionUri = $"http://{ExchangeServer}/Powershell?serializationLevel=Full";
        var userDisplayName = Get_DisplayName(userId);
        using var pw = new SecureString();

        foreach (var x in _password)
        {
            pw.AppendChar(x);
        }

        var credential = new PSCredential(_user, pw);
        var connectionInfo = new WSManConnectionInfo(
            new Uri(liveIdConnectionUri),
            "http://schemas.microsoft.com/powershell/Microsoft.Exchange",
            credential
        )
        {
            AuthenticationMechanism = AuthenticationMechanism.Default,
        };

        using var runspace = RunspaceFactory.CreateRunspace(connectionInfo);
        using var powershell = PowerShell.Create();

        runspace.Open();
        powershell.Runspace = runspace;

        var psCommand = new PSCommand();
        psCommand.AddCommand("disable-Mailbox");
        psCommand.AddParameter("Identity", userDisplayName);
        psCommand.AddParameter("Confirm", false);

        try
        {
            powershell.Commands = psCommand;
            powershell.Invoke();
        }
        catch
        {
            successCode = 1;
        }
        finally
        {
            runspace.Close();
        }

        return successCode;
    }

    // WFManual_Separations uses this method.
    public int Hide_Exchange_MB(string userId)
    {
        var successCode = 0;
        var liveIdConnectionUri = $"http://{ExchangeServer}/Powershell?serializationLevel=Full";
        var userDisplayName = Get_DisplayName(userId);
        using var pw = new SecureString();

        foreach (var x in _password)
        {
            pw.AppendChar(x);
        }

        var credential = new PSCredential((string?)_user, pw);
        var connectionInfo = new WSManConnectionInfo(
            new Uri(liveIdConnectionUri),
            "http://schemas.microsoft.com/powershell/Microsoft.Exchange",
            credential
        )
        {
            AuthenticationMechanism = AuthenticationMechanism.Default,
        };

        using var runspace = RunspaceFactory.CreateRunspace(connectionInfo);
        using var powershell = PowerShell.Create();

        runspace.Open();
        powershell.Runspace = runspace;

        var psCommand = new PSCommand();
        psCommand.AddCommand("Set-Mailbox");
        psCommand.AddParameter("Identity", userDisplayName);
        psCommand.AddParameter("HiddenFromAddressListsEnabled", true);
        psCommand.AddParameter("Confirm", false);

        try
        {
            powershell.Commands = psCommand;
            powershell.Invoke();
        }
        catch
        {
            successCode = 1;
        }
        finally
        {
            runspace.Close();
        }

        return successCode;
    }

    // Enable_New_User uses this method.
    public int Unhide_Exchange_MB(string userId)
    {
        var successCode = 0;
        var liveIdConnectionUri = $"http://{ExchangeServer}/Powershell?serializationLevel=Full";
        var userDisplayName = Get_DisplayName(userId);
        using var pw = new SecureString();

        foreach (var x in _password)
        {
            pw.AppendChar(x);
        }

        var credential = new PSCredential((string?)_user, pw);
        var connectionInfo = new WSManConnectionInfo(
            new Uri(liveIdConnectionUri),
            "http://schemas.microsoft.com/powershell/Microsoft.Exchange",
            credential
        )
        {
            AuthenticationMechanism = AuthenticationMechanism.Default,
        };

        using var runspace = RunspaceFactory.CreateRunspace(connectionInfo);
        using var powershell = PowerShell.Create();

        runspace.Open();
        powershell.Runspace = runspace;

        var psCommand = new PSCommand();
        psCommand.AddCommand("Set-Mailbox");
        psCommand.AddParameter("Identity", userDisplayName);
        psCommand.AddParameter("HiddenFromAddressListsEnabled", false);

        try
        {
            powershell.Commands = psCommand;
            powershell.Invoke();
        }
        catch
        {
            successCode = 1;
        }
        finally
        {
            runspace.Close();
        }

        return successCode;
    }

    // Enable_New_User uses this method.
    public int Enable_Exchange_MB(string userId)
    {
        var successCode = 0;
        var liveIdConnectionUri = $"http://{ExchangeServer}/Powershell?serializationLevel=Full";

        // Insert Vendor Check here
        var userAlias = Get_Alias(userId) ?? string.Empty;
        var vendorCheck = userAlias.Substring(userAlias.IndexOf('{') + 1, 6).ToLowerInvariant();

        if (vendorCheck == "vendor")
        {
            userAlias = userAlias.Replace("{Vendor}", "");
        }

        var userDistinguishedName = Get_DN(userId);
        // This throw is only here to preserve existing behavior. userDisplayName being null should be handled properly instead.
        var userDisplayName =
            Get_DisplayName(userId)
            ?? throw new ArgumentNullException("userDisplayName is null", innerException: null);
        var smtp = userDisplayName
            .Replace("(Vendor)", "")
            .Replace("@FTB", "")
            .Replace(" ", "")
            .Trim();
        var intComma = smtp.IndexOf(',');
        var lastName = smtp.Substring(0, intComma).Trim();
        var firstName = smtp.Substring(intComma + 1).Trim();
        var smtpAddress =
            vendorCheck == "vendor"
                ? $"Vendor.{firstName.Replace(" ", "")}.{lastName.Replace(" ", "")}@ftb.ca.gov"
                : $"{firstName.Replace(" ", "")}.{lastName.Replace(" ", "")}@ftb.ca.gov";

        using var pw = new SecureString();

        foreach (var x in _password)
        {
            pw.AppendChar(x);
        }

        var credential = new PSCredential(_user, pw);
        var connectionInfo = new WSManConnectionInfo(
            new Uri(liveIdConnectionUri),
            "http://schemas.microsoft.com/powershell/Microsoft.Exchange",
            credential
        )
        {
            AuthenticationMechanism = AuthenticationMechanism.Default,
        };

        using var runspace = RunspaceFactory.CreateRunspace(connectionInfo);
        using var powershell = PowerShell.Create();

        runspace.Open();
        powershell.Runspace = runspace;

        var enableMailboxCommand = new PSCommand();
        enableMailboxCommand.AddCommand("enable-mailbox");
        enableMailboxCommand.AddParameter("Identity", userDistinguishedName.Replace("LDAP://", ""));
        enableMailboxCommand.AddParameter("Alias", userAlias);
        enableMailboxCommand.AddParameter("PrimarySmtpAddress", smtpAddress);

        ///Check the policy checkbox
        var setMailboxCommand = new PSCommand();
        setMailboxCommand.AddCommand("set-mailbox");
        setMailboxCommand.AddParameter("Identity", userDistinguishedName.Replace("LDAP://", ""));
        setMailboxCommand.AddParameter("Alias", userAlias);
        setMailboxCommand.AddParameter("EmailAddressPolicyEnabled", true);

        try
        {
            powershell.Commands = enableMailboxCommand;
            powershell.Invoke();

            System.Threading.Thread.Sleep(5000);

            powershell.Commands = setMailboxCommand;
            powershell.Invoke();
        }
        catch (Exception)
        {
            successCode = 1;
        }
        finally
        {
            runspace.Close();
        }

        using var powershellInstance = PowerShell.Create();
        powershellInstance.AddScript(
            $"Set-Mailbox {userId} -RetentionPolicy 'FTB 90 - Day Email Retention Policy'"
        );
        powershellInstance.Invoke();

        return successCode;
    }
    #endregion Exchange Processes

    #region folder/file processes
    public int Delete_P_Drive(string userId)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal == null)
        {
            return 1;
        }

        var path = userPrincipal.HomeDirectory;
        //var path = @"\\Sys36001\c$\Temp\X9999_Test";

        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
            else
            {
                successCode = 1;
            }
        }
        catch
        {
            successCode = 2;
        }

        return successCode;
    }

    public int Create_P_Drive(string userId)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal == null)
        {
            return 1;
        }

        var path = userPrincipal.HomeDirectory;
        //var path = @"\\Sys36001\c$\Temp\X9999_Test";

        try
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path.ToUpperInvariant());
            }
            else
            {
                successCode = 1;
            }
        }
        catch
        {
            successCode = 2;
        }

        return successCode;
    }

    /// <summary>
    /// This code will only work if the caller is running as an account that can modify ACLs on <paramref name="userId"/>'s home directory.
    /// </summary>
    /// <param name="userId">A valid FTB user id</param>
    /// <returns></returns>
    public int Apply_Folder_Permissions(string userId)
    {
        var successCode = 0;
        using var principalContext = new PrincipalContext(
            ContextType.Domain,
            _domain,
            _user,
            _password
        );
        using var userPrincipal = UserPrincipal.FindByIdentity(principalContext, userId);

        if (userPrincipal == null)
        {
            return 1;
        }

        var path = userPrincipal.HomeDirectory;
        var myDirectoryInfo = new DirectoryInfo(path);

        try
        {
            if (!myDirectoryInfo.Exists)
            {
                Directory.CreateDirectory(path.ToUpperInvariant());
            }

            var myDirectorySecurity = myDirectoryInfo.GetAccessControl();
            myDirectorySecurity.AddAccessRule(
                new FileSystemAccessRule(
                    userId,
                    FileSystemRights.Modify,
                    InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
                    PropagationFlags.None,
                    AccessControlType.Allow
                )
            );

            // Set the new access settings.
            myDirectoryInfo.SetAccessControl(myDirectorySecurity);
        }
        catch
        {
            successCode = 1;
        }

        return successCode;
    }
    #endregion folder/file processes

    #region Mainframe Processes
    // The 2 lines of code below are specifically for Mainframe processes.
    private static bool ServerCallback(LdapConnection ldapConnection, X509Certificate cert)
    {
        return true;
    }

    private static X509Certificate? ClientCallback(
        LdapConnection ldapConnection,
        byte[][] trustedCAs
    )
    {
        return null;
    }

    public string tryMainFrame(string userId)
    {
        var mfEnvironment = "ibmhost";
        //var mfEnvironment = "devhost1";
        //var mfEnvironment = "syshost";

        using var mfAccountService = MainframeSecurityServiceFactory.CreateAccountService(
            mfEnvironment
        );
        var mfAccount = mfAccountService.Find(userId);

        return mfAccount != null ? mfAccount.DistinguishedName : string.Empty;
    }

    public string unsuspend_Acct(string userId)
    {
        var result = "";
        using var ldap = new LdapConnection("ibmhost:636"); //PROD
        // using var ldap = new LdapConnection("devhost1:636")); //DEV

        try
        {
            ldap.SessionOptions.SecureSocketLayer = true;
            ldap.SessionOptions.ProtocolVersion = 3;
            ldap.SessionOptions.VerifyServerCertificate = new VerifyServerCertificateCallback(
                ServerCallback
            );
            ldap.SessionOptions.QueryClientCertificate = new QueryClientCertificateCallback(
                ClientCallback
            );
            ldap.AuthType = AuthType.Basic;

            ldap.Bind(
                new NetworkCredential("cn=MFPBATCH,host=ppa2,o=ftb,c=us", "iqH1iYTFeP$2T#hn")
            ); //PROD
            // ldap.Bind(new NetworkCredential("cn=MFPBATCH,host=pya2,o=ftb,c=us", "i0hd$qaAtVJ#1YC")); //DEV

            var request = new SearchRequest(
                "host=ppa2,o=ftb,c=us",
                $"(&(objectclass=tssacid)(tssacid={userId}))",
                System.DirectoryServices.Protocols.SearchScope.Subtree
            ); //PROD

            //RACF Code below
            //ldap.Bind(new System.Net.NetworkCredential("racfid=MFPBATCH,profiletype=user,o=ftb", "<insert passphrase here>"));
            //SearchRequest request = new SearchRequest(cnnMFConLPARRequest_P, ("racfid=" + userId), System.DirectoryServices.Protocols.SearchScope.Subtree);

            var response = (SearchResponse)ldap.SendRequest(request);
            var entry = response.Entries[0];
            var mfUserDn = entry.DistinguishedName;

            // Unsuspend the account
            var modifyUserPassword = new DirectoryAttributeModification
            {
                Operation = DirectoryAttributeOperation.Replace,
                Name = "PasswordSuspended",
            };
            modifyUserPassword.Add("N");

            var modifyRequest = new ModifyRequest(mfUserDn, modifyUserPassword);
            modifyRequest.Modifications.Add(modifyUserPassword);

            var response1 = (ModifyResponse)ldap.SendRequest(modifyRequest);
            result = "Success!";
        }
        catch (Exception)
        {
            result = "";
        }

        return result;
    }
    #endregion Mainframe Processes

    /// <summary>
    /// Creates a DirectoryEntry for <paramref name="distinguishedName"/>. If no value is provided, the root domain naming context is used.
    /// </summary>
    /// <param name="distinguishedName">A valid Active Directory distinguished name.</param>
    /// <returns>An authenticated DirectoryEntry object for <paramref name="distinguishedName"/>.</returns>
    private DirectoryEntry CreateLdapDirectoryEntry(string distinguishedName = "") =>
        new()
        {
            Username = _user,
            Password = _password,
            AuthenticationType = AuthenticationTypes.Secure,
            Path =
                distinguishedName != string.Empty
                    ? $"LDAP://{distinguishedName}"
                    : "LDAP://DC=ftb,DC=ca,DC=gov",
            //Dev
            // Path =
            //     distinguishedName != string.Empty
            //         ? $"LDAP://{distinguishedName}"
            //         : "LDAP://DC=ftbstg,DC=ftb,DC=ca,DC=gov",
        };
}
